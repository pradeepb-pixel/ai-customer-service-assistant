"""
AWS Lambda Fulfillment Handler for Lex Bot
Handles intent routing and LLM fallback for complex queries.
"""
import json
import boto3
from config import AWS_REGION, BEDROCK_MODEL_ID


def handle_lex_event(event: dict, context) -> dict:
    """
    Main Lambda handler for AWS Lex fulfillment.
    Routes simple intents to banking API, complex queries to LLM.
    """
    intent_name = event["sessionState"]["intent"]["name"]
    
    # Route to appropriate handler
    handlers = {
        "CheckAccountBalance": handle_balance_inquiry,
        "TransactionHistory":  handle_transaction_history,
        "ReportLostCard":      handle_lost_card,
        "DisputeTransaction":  handle_dispute,
        "FallbackIntent":      handle_llm_fallback,
    }
    
    handler = handlers.get(intent_name, handle_llm_fallback)
    return handler(event)


def handle_balance_inquiry(event: dict) -> dict:
    """Handle account balance requests."""
    return _lex_response("Your account balance is currently available in the app.")


def handle_transaction_history(event: dict) -> dict:
    """Handle transaction history requests."""
    return _lex_response("I can show your last 10 transactions. Please verify your identity first.")


def handle_lost_card(event: dict) -> dict:
    """Handle lost/stolen card reports."""
    return _lex_response("I'm blocking your card now and will send a replacement within 3-5 business days.")


def handle_dispute(event: dict) -> dict:
    """Handle transaction dispute requests."""
    return _lex_response("I've initiated a dispute for that transaction. You'll hear back within 5 business days.")


def handle_llm_fallback(event: dict) -> dict:
    """Route complex queries to LLM via AWS Bedrock."""
    user_input = event.get("inputTranscript", "")
    response = _query_bedrock(user_input)
    return _lex_response(response)


def _query_bedrock(user_input: str) -> str:
    """Query AWS Bedrock Claude for complex customer queries."""
    client = boto3.client("bedrock-runtime", region_name=AWS_REGION)
    # Bedrock Claude invocation placeholder
    return "I understand your question. Let me connect you with a specialist."


def _lex_response(message: str) -> dict:
    """Format response for AWS Lex."""
    return {
        "sessionState": {"dialogAction": {"type": "Close"},
                         "intent": {"state": "Fulfilled"}},
        "messages": [{"contentType": "PlainText", "content": message}]
    }
