import os
from dotenv import load_dotenv
load_dotenv()

AWS_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-sonnet-20240229-v1:0")
LEX_BOT_ID = os.getenv("LEX_BOT_ID", "")
LEX_BOT_ALIAS_ID = os.getenv("LEX_BOT_ALIAS_ID", "")
