"""
AI Customer Service Assistant
Built with AWS Lex + LLM for Citi Bank
Author: Pradeep B | Data Scientist @ Citi Bank
"""

from lambda.fulfillment import handle_lex_event

def main():
    """Entry point for local testing of the chatbot."""
    sample_event = {
        "sessionState": {
            "intent": {
                "name": "CheckAccountBalance",
                "slots": {
                    "AccountType": {"value": {"interpretedValue": "checking"}}
                }
            }
        },
        "inputTranscript": "What is my checking account balance?"
    }
    response = handle_lex_event(sample_event, {})
    print(f"Bot Response: {response['messages'][0]['content']}")

if __name__ == "__main__":
    main()
